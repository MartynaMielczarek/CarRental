export class Car {
    id: number;
    name: string;
    carPrice: number;
    numberOfSeat: number;
    limit: number;
    deposit: number;
    available: boolean;
  


    constructor(id: number, name: string, carPrice: number, numberOfSeat: number, limit: number, deposit: number, available: boolean) {
        this.id=id;
        this.name=name;
        this.carPrice=carPrice;
        this.numberOfSeat=numberOfSeat;
        this.limit=limit;
        this.deposit=deposit;
        this.available=available;
      }



}
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { MainContentComponent } from './main-content/main-content.component';
import { FooterComponent } from './footer/footer.component';
import {CarTilesComponent} from './main-content/car-tiles/car-tiles.component';
import {CarTileComponent} from './main-content/car-tiles/car-tile/car-tile.component';
import { MessageComponent } from './message/message.component';
import { AdminComponent } from './admin/admin.component';
import { AppRoutingModule } from './app-routing.module';
import { CarListComponent } from './admin/car-list/car-list.component';
import { RantalHistoryComponent } from './admin/rantal-history/rantal-history.component';
import { CarDetailsComponent } from './admin/car-details/car-details.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import {HttpClientModule} from '@angular/common/http';
import {AdminCarEditComponent} from './admin/admin-car-list/admin-car-edit/admin-car-edit.component';
import {AdminCarListComponent} from './admin/admin-car-list/admin-car-list.component';
import { ReactiveFormsModule } from '@angular/forms';


//import { CarDetailsEditComponent } from './admin/car-details-edit/car-details-edit.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MainContentComponent,
    FooterComponent,
    CarTilesComponent,
    CarTileComponent,
    MessageComponent,
    AdminComponent,
    CarListComponent,
    RantalHistoryComponent,
    CarDetailsComponent,
    PageNotFoundComponent,
    AdminCarEditComponent,
    AdminCarListComponent
    //CarDetailsEditComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
  HttpClientModule,
  ReactiveFormsModule

 ],
   
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

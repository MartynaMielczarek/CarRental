import { Component, OnInit } from '@angular/core';
import { CarService } from 'src/app/cars.service';
import { Car } from 'src/app/car';

@Component({
  selector: 'app-admin-car-list',
  templateUrl: './admin-car-list.component.html',
  styleUrls: ['./admin-car-list.component.css']
})
export class AdminCarListComponent implements OnInit {
  carList:Car[];

  constructor(private carService:CarService) { }

  ngOnInit(): void {
    this.carService.getCars().subscribe(carList => {
        console.log('got list of cars', carList);
      this.carList = carList;
      }
    );
  }
}



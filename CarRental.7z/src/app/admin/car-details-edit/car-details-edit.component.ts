import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car-details-edit',
  templateUrl: './car-details-edit.component.html',
  styleUrls: ['./car-details-edit.component.css']
})
export class CarDetailsEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

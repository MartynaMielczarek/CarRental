import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RantalHistoryComponent } from './rantal-history.component';

describe('RantalHistoryComponent', () => {
  let component: RantalHistoryComponent;
  let fixture: ComponentFixture<RantalHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RantalHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RantalHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rantal-history',
  templateUrl: './rantal-history.component.html',
  styleUrls: ['./rantal-history.component.css']
})
export class RantalHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

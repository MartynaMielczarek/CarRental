import { Component, OnInit } from '@angular/core';
import { CarService } from 'src/app/cars.service';
import { Car } from 'src/app/car';

@Component({
  selector: 'app-car-list',
  templateUrl: './car-list.component.html',
  styleUrls: ['./car-list.component.css']
})
export class CarListComponent implements OnInit {

  carList: Car[];

  constructor(private carService: CarService) { 

  }

ngOnInit() {
    this.carService.getCars().subscribe(cars => {
      this.carList = cars;
    });

}
}




import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Car } from 'src/app/car';
import { CarService } from 'src/app/cars.service';

@Component({
  selector: 'app-car-details',
  templateUrl: './car-details.component.html',
  styleUrls: ['./car-details.component.css']
})


    export class CarDetailsComponent implements OnInit {
      car: Car;
    
      constructor(private router: Router, private route: ActivatedRoute, private carsService: CarService) {
      }

      goBackToCars() { this.router.navigate(['admin', 'cars']);}
    
      ngOnInit() {
        /*this.route.params.subscribe(parameters => {
          console.log(parameters);
          this.car = this.carsService.getCarById(+parameters['id']);
        })*/
      }
    }
  

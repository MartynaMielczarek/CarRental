import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-car-tile',
  templateUrl: './car-tile.component.html',
  styleUrls: ['./car-tile.component.css']
})
export class CarTileComponent implements OnInit {
  @Input() name;
  @Input() carPrice;
  @Input() numberOfSeat;
  @Input() limit;
  @Input() deposit;
  @Input() available;

  constructor() { }

  ngOnInit(): void {
  }
  onRentCar(): void { if (this.available === true) {   this.available = false; } else {   this.available = true; } }

}

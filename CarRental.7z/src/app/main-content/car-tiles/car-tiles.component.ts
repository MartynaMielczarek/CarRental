
import { Component, OnInit } from '@angular/core';
import { CarService } from 'src/app/cars.service';
import { Car } from 'src/app/car';
import { MessageService } from 'src/app/message/message.service';

@Component({
  selector: 'app-car-tiles',
  templateUrl: './car-tiles.component.html',
  styleUrls: ['./car-tiles.component.css']
})
export class CarTilesComponent implements OnInit {

  carList: Car[];

  constructor(private carService: CarService) {
  }

  ngOnInit(): void {
    this.carService.getCars().subscribe(carList => {
        console.log('got list of cars', carList);
      this.carList = carList;
      }
    );
  }

}